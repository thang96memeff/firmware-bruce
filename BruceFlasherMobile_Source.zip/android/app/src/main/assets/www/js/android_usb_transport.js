/**
 * ==============================================================================
 * DUSCU FLASHER ANDROID - USB OTG TRANSPORT BRIDGE
 * ==============================================================================
 * File: android_usb_transport.js
 * Nhiệm vụ:
 * 1. Cung cấp Polyfill chuẩn Web Serial API (navigator.serial) cho Android WebView.
 * 2. Cầu nối dữ liệu 2 chiều giữa ESPLoader (JavaScript) và Android Native (UsbBridge.kt).
 * 3. Hỗ trợ toàn diện các dòng chip USB: CH340, CP210x, CDC/ACM (ESP32-S3/C5), FTDI.
 * 4. Tự động tải firmware vào bộ nhớ đệm tạm và TỰ ĐỘNG XÓA SẠCH file (.bin) ngay
 *    sau khi nạp xong hoặc khi gặp lỗi theo chỉ thị của Chủ tịch Thăng!
 * ==============================================================================
 */

(function() {
  if (typeof window === 'undefined') return;

  // Nhận diện đang chạy trong môi trường ứng dụng Android Native
  window.isAndroidApp = Boolean(window.AndroidUSB);

  if (!window.isAndroidApp) {
    console.log("[AndroidUSB] Chạy trên trình duyệt Web thông thường (không qua Android OTG).");
    return;
  }

  console.log("%c[AndroidUSB] ĐÃ KÍCH HOẠT CẦU NỐI USB OTG CHO ANDROID NATIVE! 🚀", "color: #00ff88; font-weight: bold; font-size: 14px;");

  // Bộ chuyển đổi Base64 sang Uint8Array tốc độ cao
  function base64ToUint8Array(base64) {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }

  // Bộ chuyển đổi Uint8Array sang Base64
  function uint8ArrayToBase64(bytes) {
    let binary = '';
    const len = bytes.byteLength;
    const chunkSize = 8192; // Tránh tràn stack khi convert buffer lớn
    for (let i = 0; i < len; i += chunkSize) {
      const slice = bytes.subarray(i, Math.min(i + chunkSize, len));
      binary += String.fromCharCode.apply(null, slice);
    }
    return btoa(binary);
  }

  /**
   * ----------------------------------------------------------------------------
   * CLASS: AndroidSerialPort (Mô phỏng chuẩn Web Serial API SerialPort)
   * ----------------------------------------------------------------------------
   */
  class AndroidSerialPort {
    constructor() {
      this.isOpen = false;
      this.baudRate = 115200;
      this.readable = null;
      this.writable = null;
      this._reader = null;
      this._writer = null;
      this._streamController = null;
      this._connectResolver = null;
      this._connectRejecter = null;
      this._deviceInfo = null;
    }

    getInfo() {
      return this._deviceInfo || {
        usbVendorId: 0x0000,
        usbProductId: 0x0000,
        driver: "Android_UsbSerial_OTG"
      };
    }

    /**
     * Mở cổng Serial với cấu hình baudRate
     */
    async open(options = {}) {
      if (this.isOpen) {
        throw new Error("Cổng Serial đã được mở.");
      }

      this.baudRate = options.baudRate || 115200;
      console.log(`[AndroidSerial] Đang mở cổng với tốc độ BaudRate: ${this.baudRate}...`);

      return new Promise((resolve, reject) => {
        this._connectResolver = resolve;
        this._connectRejecter = reject;

        // Gọi lệnh kết nối Native xuống Android
        window.AndroidUSB.connect(this.baudRate);

        // Thiết lập timeout 10 giây nếu người dùng không cắm cáp hoặc không phản hồi
        setTimeout(() => {
          if (this._connectRejecter) {
            const errFn = this._connectRejecter;
            this._connectResolver = null;
            this._connectRejecter = null;
            errFn(new Error("Hết thời gian chờ kết nối thiết bị USB OTG. Hãy chắc chắn đã cắm cáp và cấp quyền."));
          }
        }, 10000);
      });
    }

    /**
     * Khởi tạo các luồng ReadableStream & WritableStream sau khi cổng mở thành công
     */
    _initStreams() {
      // 1. Luồng Đọc (ReadableStream)
      if (typeof ReadableStream !== 'undefined') {
        this.readable = new ReadableStream({
          start: (controller) => {
            this._streamController = controller;
          },
          cancel: () => {
            this._streamController = null;
          }
        });
      } else {
        // Fallback đơn giản cho WebView cực cũ
        this.readable = {
          getReader: () => ({
            read: async () => new Promise(res => { this._legacyReaderResolver = res; }),
            releaseLock: () => {}
          })
        };
      }

      // 2. Luồng Ghi (WritableStream)
      if (typeof WritableStream !== 'undefined') {
        this.writable = new WritableStream({
          write: async (chunk) => {
            return this._writeChunk(chunk);
          },
          close: () => {},
          abort: () => {}
        });
      } else {
        this.writable = {
          getWriter: () => ({
            write: async (chunk) => this._writeChunk(chunk),
            releaseLock: () => {}
          })
        };
      }
    }

    /**
     * Ghi một khối dữ liệu Uint8Array xuống USB qua Native
     */
    async _writeChunk(chunk) {
      if (!this.isOpen) return;
      let bytes;
      if (chunk instanceof Uint8Array) {
        bytes = chunk;
      } else if (chunk.buffer) {
        bytes = new Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength);
      } else {
        bytes = new Uint8Array(chunk);
      }

      const b64 = uint8ArrayToBase64(bytes);
      const sent = window.AndroidUSB.writeBase64(b64);
      if (sent < 0) {
        throw new Error("Lỗi gửi dữ liệu qua cổng USB OTG.");
      }
    }

    /**
     * Điều khiển tín hiệu chân DTR / RTS (Reset bo mạch & đưa vào Bootloader)
     */
    async setSignals(signals = {}) {
      if (!window.AndroidUSB) return;

      if (signals.dataTerminalReady !== undefined) {
        window.AndroidUSB.setDTR(Boolean(signals.dataTerminalReady));
      }
      if (signals.requestToSend !== undefined) {
        window.AndroidUSB.setRTS(Boolean(signals.requestToSend));
      }
    }

    /**
     * Ngắt kết nối và đóng cổng Serial
     */
    async close() {
      console.log("[AndroidSerial] Đang đóng cổng Serial USB OTG...");
      this.isOpen = false;
      if (this._streamController) {
        try { this._streamController.close(); } catch(e) {}
        this._streamController = null;
      }
      if (window.AndroidUSB) {
        window.AndroidUSB.disconnect();
      }
      this.readable = null;
      this.writable = null;
    }

    /**
     * Xử lý khi nhận được dữ liệu từ Android Native
     */
    _onData(bytes) {
      if (this._streamController) {
        try {
          this._streamController.enqueue(bytes);
        } catch(e) {
          console.warn("[AndroidSerial] Lỗi enqueue stream:", e);
        }
      } else if (this._legacyReaderResolver) {
        const res = this._legacyReaderResolver;
        this._legacyReaderResolver = null;
        res({ value: bytes, done: false });
      }
    }
  }

  // Khởi tạo đối tượng Singleton cổng Serial
  const androidPort = new AndroidSerialPort();

  /**
   * ----------------------------------------------------------------------------
   * CLASS: AndroidSerial (Polyfill cho navigator.serial)
   * ----------------------------------------------------------------------------
   */
  class AndroidSerial extends EventTarget {
    constructor() {
      super();
      this._port = androidPort;
    }

    async requestPort(options = {}) {
      if (!window.AndroidUSB) {
        throw new Error("Không tìm thấy môi trường Android USB.");
      }
      const count = window.AndroidUSB.getAttachedDevicesCount ? window.AndroidUSB.getAttachedDevicesCount() : 0;
      if (count === 0) {
        const errorMsg = "Chưa phát hiện thiết bị nào cắm vào cổng USB OTG!\n\n• Vui lòng cắm cáp OTG từ điện thoại vào bo mạch (ESP32 / BW16).\n• Với máy OPPO, Realme, Vivo: hãy vào Cài đặt và BẬT 'Kết nối OTG' rồi bấm lại.";
        if (typeof window.logSys === 'function') {
          window.logSys("[LỖI USB] " + errorMsg.replace(/\n\n/g, ' -- '), "error");
        }
        throw new Error(errorMsg);
      }

      // Có thiết bị thực tế cắm vào!
      let info = { usbVendorId: 0x1A86, usbProductId: 0x7523, driver: "CH340" };
      try {
        const rawInfo = window.AndroidUSB.getAttachedDeviceInfo ? window.AndroidUSB.getAttachedDeviceInfo() : "{}";
        const parsed = JSON.parse(rawInfo);
        if (parsed.vendorId) {
          info = {
            usbVendorId: parsed.vendorId,
            usbProductId: parsed.productId,
            driver: parsed.driver || "Android_UsbSerial_OTG",
            productName: parsed.name
          };
        }
      } catch(e) {}

      this._port._deviceInfo = info;
      return this._port;
    }

    async getPorts() {
      // Trả về cổng nếu đã cắm hoặc rỗng
      return [this._port];
    }
  }

  // Ghi đè hoặc thiết lập navigator.serial
  const androidSerialInstance = new AndroidSerial();
  try {
    Object.defineProperty(navigator, 'serial', {
      value: androidSerialInstance,
      writable: true,
      configurable: true
    });
    console.log("[AndroidUSB] Đã polyfill navigator.serial thành công!");
  } catch(e) {
    navigator.serial = androidSerialInstance;
  }

  /**
   * ----------------------------------------------------------------------------
   * CÁC CALLBACK TỪ ANDROID NATIVE TRUYỀN LÊN
   * ----------------------------------------------------------------------------
   */

  // 1. Khi cổng USB kết nối thành công
  window.onPortConnected = function(msg) {
    console.log("[AndroidUSB] Native thông báo kết nối thành công:", msg);
    androidPort.isOpen = true;
    androidPort._initStreams();
    if (androidPort._connectResolver) {
      androidPort._connectResolver(androidPort);
      androidPort._connectResolver = null;
      androidPort._connectRejecter = null;
    }
    androidSerialInstance.dispatchEvent(new CustomEvent('connect', { detail: { port: androidPort } }));
  };

  // 2. Khi cổng USB bị ngắt kết nối (hoặc rút cáp)
  window.onPortDisconnected = function(msg) {
    console.log("[AndroidUSB] Native thông báo ngắt kết nối:", msg);
    androidPort.isOpen = false;
    androidSerialInstance.dispatchEvent(new CustomEvent('disconnect', { detail: { port: androidPort } }));
  };

  // 3. Khi cổng USB gặp lỗi
  window.onPortError = function(errMsg) {
    console.error("[AndroidUSB] Lỗi cổng USB:", errMsg);
    if (androidPort._connectRejecter) {
      androidPort._connectRejecter(new Error(errMsg));
      androidPort._connectResolver = null;
      androidPort._connectRejecter = null;
    }
  };

  // 4. Khi nhận luồng byte Serial từ thiết bị
  window.onSerialDataReceived = function(base64Data) {
    try {
      const bytes = base64ToUint8Array(base64Data);
      androidPort._onData(bytes);
    } catch(e) {
      console.error("[AndroidUSB] Lỗi parse dữ liệu Serial Base64:", e);
    }
  };

  // 5. Khi hoàn tất phát xung Reset mạch
  window.onResetDone = function(msg) {
    console.log("[AndroidUSB] Reset bo mạch:", msg);
  };

  /**
   * ----------------------------------------------------------------------------
   * BỘ TẢI VÀ TỰ ĐỘNG XÓA SẠCH FIRMWARE (Zero-Footprint Firmware Engine)
   * Theo đúng chỉ đạo tuyệt đối của Chủ tịch Thăng:
   * "Tự động tải về đệm tạm khi nạp -> XÓA SẠCH FILE NGAY SAU KHI NẠP HOẶC GẶP LỖI"
   * ----------------------------------------------------------------------------
   */
  window.AndroidFirmwareDownloader = {
    /**
     * Tải firmware tự động qua Native Android và trả về Uint8Array
     * @param {string} boardId - Mã bo mạch (vd: esp32-s3-devkitc-1)
     * @param {string} binFileName - Tên file binary (vd: Bruce-esp32-s3-devkitc-1.bin)
     * @param {Function} onProgress - Callback tiến độ tải (percent, read, total)
     * @returns {Promise<Uint8Array>}
     */
    getFirmwareData: async function(boardId, binFileName, onProgress) {
      console.log(`[AndroidDownloader] Bắt đầu tải firmware cho [${boardId}]: ${binFileName}...`);

      return new Promise((resolve, reject) => {
        window._androidDownloadListeners = {
          onProgress: (pct, read, total) => {
            if (typeof onProgress === 'function') onProgress(pct, read, total);
          },
          onSuccess: async (fileSize) => {
            console.log(`[AndroidDownloader] Tải thành công (${fileSize} bytes). Đang chuyển dữ liệu vào RAM...`);
            try {
              const fullBuffer = new Uint8Array(fileSize);
              let offset = 0;
              const chunkSize = 64 * 1024; // Đọc từng khối 64KB để không làm lag UI

              while (offset < fileSize) {
                const readLen = Math.min(chunkSize, fileSize - offset);
                const chunkB64 = window.AndroidUSB.readFirmwareChunkBase64(offset, readLen);
                if (!chunkB64) {
                  throw new Error(`Lỗi đọc khối dữ liệu firmware tại offset ${offset}`);
                }
                const chunkBytes = base64ToUint8Array(chunkB64);
                fullBuffer.set(chunkBytes, offset);
                offset += readLen;
              }

              console.log("[AndroidDownloader] Đã tải toàn bộ firmware vào RAM thành công!");

              // TỰ ĐỘNG XÓA SẠCH FILE NGAY LẬP TỨC KHỎI BỘ NHỚ THEO CHỈ THỊ CỦA CHỦ TỊCH THĂNG
              window.AndroidUSB.finishAndCleanupFirmware();
              console.log("[AndroidDownloader] ĐÃ TỰ ĐỘNG XÓA SẠCH FILE FIRMWARE TRÊN BỘ NHỚ ĐỆM! 🧹✨");

              resolve(fullBuffer);
            } catch(err) {
              // Nếu có lỗi lúc đọc buffer, cũng phải xóa sạch file đệm
              window.AndroidUSB.finishAndCleanupFirmware();
              reject(err);
            }
          },
          onError: (errMsg) => {
            console.error("[AndroidDownloader] Lỗi tải firmware:", errMsg);
            // Gặp lỗi thì lập tức xóa sạch file tạm nếu có
            window.AndroidUSB.finishAndCleanupFirmware();
            reject(new Error(errMsg));
          }
        };

        // Kích hoạt Native bắt đầu tải
        window.AndroidUSB.startDownloadAndPrepare(boardId, binFileName);
      });
    },

    /**
     * Gọi xóa sạch file firmware thủ công nếu cần
     */
    cleanup: function() {
      if (window.AndroidUSB && typeof window.AndroidUSB.finishAndCleanupFirmware === 'function') {
        window.AndroidUSB.finishAndCleanupFirmware();
      }
    }
  };

  // Callback sự kiện tải xuống từ Native
  window.onDownloadProgress = function(dataStr) {
    const parts = dataStr.split(',');
    const percent = parseInt(parts[0]) || 0;
    const read = parseInt(parts[1]) || 0;
    const total = parseInt(parts[2]) || 0;
    if (window._androidDownloadListeners && window._androidDownloadListeners.onProgress) {
      window._androidDownloadListeners.onProgress(percent, read, total);
    }
  };

  window.onDownloadSuccess = function(sizeStr) {
    const size = parseInt(sizeStr) || 0;
    if (window._androidDownloadListeners && window._androidDownloadListeners.onSuccess) {
      window._androidDownloadListeners.onSuccess(size);
    }
  };

  window.onDownloadError = function(errMsg) {
    if (window._androidDownloadListeners && window._androidDownloadListeners.onError) {
      window._androidDownloadListeners.onError(errMsg);
    }
  };

  window.onFirmwareCleaned = function(msg) {
    console.log("[AndroidUSB] " + msg);
  };

})();
