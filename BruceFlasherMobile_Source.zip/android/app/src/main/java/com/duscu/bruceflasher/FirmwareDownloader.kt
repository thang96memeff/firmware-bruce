package com.duscu.bruceflasher

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.TimeUnit

/**
 * FirmwareDownloader: Module tải firmware thông minh cho Bruce Flasher Android.
 * 
 * Tính năng chính (theo chỉ thị của Chủ tịch Thăng):
 * 1. Kiểm tra dung lượng bộ nhớ khả dụng trước khi tải (đảm bảo thiết bị đủ chỗ).
 * 2. Fallback đa đường truyền (GitHub Pages CDN, GitHub Releases, GitHub Raw, GitHub Blob, jsDelivr CDN).
 * 3. Tự động xóa sạch file tạm (.bin) ngay sau khi nạp xong hoặc khi gặp bất kỳ ngoại lệ nào.
 * 4. Tự động dọn dẹp các tệp tạm cũ lúc khởi động ứng dụng để bảo vệ bộ nhớ người dùng.
 */
class FirmwareDownloader(private val context: Context) {

    companion object {
        private const val TAG = "FirmwareDownloader"
        private const val MIN_REQUIRED_STORAGE_BYTES = 20 * 1024 * 1024L // Cần tối thiểu 20MB trống
        private const val BUFFER_SIZE = 8192
        private const val TEMP_PREFIX = "temp_bruce_"
        private const val TEMP_SUFFIX = ".bin"

        // Danh sách mirror đa nguồn dự phòng
        private val MIRROR_BASE_URLS = listOf(
            "https://thang96memeff.github.io/firmware-bruce/",
            "https://raw.githubusercontent.com/thang96memeff/firmware-bruce/main/",
            "https://github.com/thang96memeff/firmware-bruce/releases/latest/download/",
            "https://github.com/thang96memeff/firmware-bruce/raw/main/",
            "https://cdn.jsdelivr.net/gh/thang96memeff/firmware-bruce@main/"
        )
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    init {
        // Tự động dọn dẹp mọi tệp tạm còn sót lại từ phiên trước khi khởi tạo
        cleanAllTempFiles()
    }

    /**
     * Kiểm tra dung lượng bộ nhớ trống khả dụng trên thiết bị
     */
    fun hasSufficientStorage(minBytes: Long = MIN_REQUIRED_STORAGE_BYTES): Boolean {
        val usable = context.cacheDir.usableSpace
        val hasSpace = usable >= minBytes
        if (!hasSpace) {
            val freeMb = usable / (1024 * 1024)
            val reqMb = minBytes / (1024 * 1024)
            Log.e(TAG, "[STORAGE] Bộ nhớ khả dụng không đủ: còn $freeMb MB / cần tối thiểu $reqMb MB")
        }
        return hasSpace
    }

    /**
     * Tự động tải firmware .bin về thư mục đệm tạm (cacheDir).
     * BẢO ĐẢM TỰ ĐỘNG XÓA SẠCH NẾU GẶP LỖI HOẶC BỊ HỦY BỎ.
     */
    suspend fun downloadFirmware(
        boardId: String,
        binFileName: String,
        onProgress: (percent: Int, bytesRead: Long, totalBytes: Long) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        // 1. Kiểm tra dung lượng bộ nhớ
        if (!hasSufficientStorage()) {
            val freeMb = context.cacheDir.usableSpace / (1024 * 1024)
            return@withContext Result.failure(
                IOException("Dung lượng bộ nhớ khả dụng không đủ (còn ${freeMb}MB, cần tối thiểu 20MB trống).")
            )
        }

        val targetName = when {
            binFileName.endsWith(".bin") -> binFileName
            binFileName.isNotBlank() -> "$binFileName.bin"
            else -> "Bruce-$boardId.bin"
        }

        val tempFile = File(context.cacheDir, "${TEMP_PREFIX}${System.currentTimeMillis()}${TEMP_SUFFIX}").apply {
            deleteOnExit()
        }

        var downloadSucceeded = false
        var lastException: Exception? = null

        try {
            // 2. Thử lần lượt các URL từ danh sách mirror đa nguồn
            for ((index, base) in MIRROR_BASE_URLS.withIndex()) {
                val candidateUrl = "$base$targetName?t=${System.currentTimeMillis()}"
                Log.d(TAG, "[MIRROR ${index + 1}/${MIRROR_BASE_URLS.size}] Đang kết nối tới: $candidateUrl")

                try {
                    val request = Request.Builder()
                        .url(candidateUrl)
                        .header("User-Agent", "Mozilla/5.0 BruceFlasherAndroid/1.0")
                        .header("Accept", "application/octet-stream, */*")
                        .build()

                    client.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) {
                            throw IOException("HTTP ${response.code}: ${response.message}")
                        }

                        val body = response.body ?: throw IOException("Nội dung phản hồi rỗng")
                        val totalLength = body.contentLength()

                        // Kiểm tra nếu nội dung quá nhỏ (< 100KB) thì có thể là trang lỗi HTML
                        if (totalLength in 1..102400) {
                            val contentType = body.contentType()?.toString()?.lowercase() ?: ""
                            if (contentType.contains("text/html")) {
                                throw IOException("URL trả về trang HTML thay vì file nhị phân binary")
                            }
                        }

                        var input: InputStream? = null
                        var output: FileOutputStream? = null
                        try {
                            input = body.byteStream()
                            output = FileOutputStream(tempFile)

                            val buffer = ByteArray(BUFFER_SIZE)
                            var bytesRead: Long = 0
                            var read: Int

                            while (input.read(buffer).also { read = it } != -1) {
                                output.write(buffer, 0, read)
                                bytesRead += read
                                if (totalLength > 0) {
                                    val percent = ((bytesRead * 100) / totalLength).toInt().coerceIn(0, 100)
                                    onProgress(percent, bytesRead, totalLength)
                                } else {
                                    onProgress(-1, bytesRead, -1)
                                }
                            }
                            output.flush()

                            if (tempFile.length() > 0) {
                                downloadSucceeded = true
                                Log.i(TAG, "[THÀNH CÔNG] Đã tải firmware về tệp tạm: ${tempFile.name} (${tempFile.length()} bytes)")
                                return@withContext Result.success(tempFile)
                            } else {
                                throw IOException("Tệp tải về có kích thước 0 byte")
                            }
                        } finally {
                            input?.close()
                            output?.close()
                        }
                    }
                } catch (e: CancellationException) {
                    // Nếu Coroutine bị hủy (người dùng bấm Cancel), ném lại để xử lý dọn dẹp
                    throw e
                } catch (e: Exception) {
                    lastException = e
                    Log.w(TAG, "[MIRROR ${index + 1} THẤT BẠI] $candidateUrl: ${e.message}")
                    if (tempFile.exists()) {
                        tempFile.delete()
                    }
                }
            }
        } catch (e: CancellationException) {
            deleteTempFirmware(tempFile)
            throw e
        } finally {
            // NGUYÊN TẮC VÀNG CỦA CHỦ TỊCH THĂNG: Nếu chưa tải thành công 100%, xóa ngay lập tức
            if (!downloadSucceeded && tempFile.exists()) {
                deleteTempFirmware(tempFile)
            }
        }

        val errMsg = lastException?.message ?: "Không thể tải firmware từ bất kỳ nguồn mirror nào."
        return@withContext Result.failure(IOException(errMsg, lastException))
    }

    /**
     * TỰ ĐỘNG XÓA SẠCH file firmware tạm sau khi nạp xong hoặc gặp lỗi.
     * Giải phóng 100% dung lượng bộ nhớ cho điện thoại của người dùng.
     */
    fun deleteTempFirmware(file: File?): Boolean {
        if (file == null) return false
        return try {
            if (file.exists()) {
                val name = file.name
                val size = file.length()
                val deleted = file.delete()
                Log.d(TAG, "[CLEANUP] Đã xóa file firmware tạm: $name (${size} bytes) -> Kết quả: $deleted")
                deleted
            } else {
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "[CLEANUP ERROR] Lỗi khi xóa file tạm ${file.name}: ${e.message}")
            false
        }
    }

    /**
     * Dọn dẹp triệt để tất cả các file firmware tạm còn sót lại trong cả cacheDir và filesDir
     */
    fun cleanAllTempFiles() {
        try {
            var count = 0
            val dirs = listOf(context.cacheDir, context.filesDir)
            for (dir in dirs) {
                dir?.listFiles()?.forEach { file ->
                    if (file.isFile && file.name.startsWith(TEMP_PREFIX) && file.name.endsWith(TEMP_SUFFIX)) {
                        val deleted = file.delete()
                        if (deleted) count++
                    }
                }
            }
            if (count > 0) {
                Log.i(TAG, "[CLEANUP] Đã tự động dọn sạch $count file firmware tạm cũ còn sót lại.")
            }
        } catch (e: Exception) {
            Log.w(TAG, "[CLEANUP ERROR] Lỗi dọn tệp tạm cũ: ${e.message}")
        }
    }
}
