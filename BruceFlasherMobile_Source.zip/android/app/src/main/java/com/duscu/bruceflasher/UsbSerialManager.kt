package com.duscu.bruceflasher

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import android.util.Log
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager
import java.io.IOException
import java.util.concurrent.Executors

/**
 * UsbSerialManager: Điều khiển kết nối USB OTG trên Android
 * Hỗ trợ CH340, CP210x, CDC/ACM (Native ESP32-S3/C5), FTDI.
 */
class UsbSerialManager(
    private val context: Context,
    private val onDataReceived: (ByteArray) -> Unit,
    private val onStatusChanged: (String, Boolean) -> Unit
) : SerialInputOutputManager.Listener {

    private val TAG = "UsbSerialManager"
    private val ACTION_USB_PERMISSION = "com.duscu.bruceflasher.USB_PERMISSION"

    private val usbManager: UsbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private var usbSerialPort: UsbSerialPort? = null
    private var usbIoManager: SerialInputOutputManager? = null
    private var usbConnection: UsbDeviceConnection? = null

    private var permissionCallback: ((Boolean) -> Unit)? = null

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_USB_PERMISSION -> {
                    synchronized(this) {
                        val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                        }
                        val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                        Log.d(TAG, "USB Permission result for ${device?.deviceName}: $granted")
                        permissionCallback?.invoke(granted)
                        permissionCallback = null
                    }
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    Log.d(TAG, "USB Device attached (UsbSerialManager)")
                    onStatusChanged("Phát hiện thiết bị USB OTG mới cắm vào.", false)
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    Log.d(TAG, "USB Device detached")
                    disconnect()
                    onStatusChanged("Thiết bị USB đã ngắt kết nối.", false)
                }
            }
        }
    }

    init {
        val filter = IntentFilter(ACTION_USB_PERMISSION).apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(usbReceiver, filter)
        }
    }

    fun destroy() {
        disconnect()
        try {
            context.unregisterReceiver(usbReceiver)
        } catch (e: Exception) {}
    }

    fun isConnected(): Boolean = usbSerialPort != null && usbSerialPort!!.isOpen

    /**
     * Tìm thiết bị USB Serial khả dụng gần nhất
     */
    fun findAvailableDriver(): UsbSerialDriver? {
        val availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (availableDrivers.isEmpty()) {
            return null
        }
        return availableDrivers[0]
    }

    /**
     * Lấy số lượng thiết bị USB Serial được hỗ trợ đang cắm vào máy
     */
    fun getAvailableDriversCount(): Int {
        val availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        return availableDrivers.size
    }

    /**
     * Lấy thông tin thiết bị đang cắm dạng JSON
     */
    fun getAttachedDeviceInfoJson(): String {
        val driver = findAvailableDriver() ?: return "{}"
        val dev = driver.device
        val vid = dev.vendorId
        val pid = dev.productId
        val name = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            dev.productName ?: dev.deviceName
        } else {
            dev.deviceName
        }
        val driverSimpleName = driver.javaClass.simpleName
        val cleanName = (name ?: "USB Serial").replace("\"", "\\\"")
        return """{"vendorId":$vid,"productId":$pid,"name":"$cleanName","driver":"$driverSimpleName"}"""
    }

    /**
     * Yêu cầu quyền truy cập USB từ người dùng
     */
    fun requestPermission(driver: UsbSerialDriver, onResult: (Boolean) -> Unit) {
        val device = driver.device
        if (usbManager.hasPermission(device)) {
            onResult(true)
            return
        }

        permissionCallback = onResult
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        val permissionIntent = PendingIntent.getBroadcast(context, 0, Intent(ACTION_USB_PERMISSION), flags)
        usbManager.requestPermission(device, permissionIntent)
    }

    /**
     * Mở cổng Serial với Baudrate tương ứng
     */
    fun open(driver: UsbSerialDriver, baudRate: Int = 115200): Boolean {
        disconnect()

        val connection = usbManager.openDevice(driver.device) ?: run {
            onStatusChanged("Không thể mở kết nối thiết bị USB (kiểm tra quyền truy cập).", false)
            return false
        }
        usbConnection = connection

        val port = driver.ports[0] // Cổng 0
        try {
            port.open(connection)
            port.setParameters(baudRate, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)

            // Cấu hình DTR và RTS cho ESP32 Bootloader
            port.dtr = true
            port.rts = false

            usbSerialPort = port

            // Khởi chạy bộ đọc nền
            usbIoManager = SerialInputOutputManager(port, this).apply {
                Executors.newSingleThreadExecutor().submit(this)
            }

            onStatusChanged("Đã kết nối cổng USB Serial @ $baudRate baud.", true)
            return true
        } catch (e: IOException) {
            Log.e(TAG, "Lỗi khi mở cổng serial: ${e.message}")
            disconnect()
            onStatusChanged("Lỗi mở cổng USB: ${e.message}", false)
            return false
        }
    }

    /**
     * Thay đổi tốc độ Baudrate (chuyển đổi giữa 115200 và 921600 lúc nạp)
     */
    fun setBaudRate(baudRate: Int): Boolean {
        return try {
            usbSerialPort?.setParameters(baudRate, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            true
        } catch (e: IOException) {
            Log.e(TAG, "Không thể đổi baudrate: ${e.message}")
            false
        }
    }

    /**
     * Đặt tín hiệu DTR và RTS (dùng để reset chip vào Bootloader hoặc Normal Mode)
     */
    fun setDTR(state: Boolean) {
        try { usbSerialPort?.dtr = state } catch (e: Exception) {}
    }

    fun setRTS(state: Boolean) {
        try { usbSerialPort?.rts = state } catch (e: Exception) {}
    }

    /**
     * Phát xung Reset phần cứng về Normal Run Mode
     */
    fun resetBoard() {
        try {
            setDTR(false)
            setRTS(true)
            Thread.sleep(100)
            setRTS(false)
            Log.d(TAG, "Đã phát xung Reset đưa board về Normal Mode.")
        } catch (e: Exception) {
            Log.w(TAG, "Lỗi reset board: ${e.message}")
        }
    }

    /**
     * Gửi mảng byte dữ liệu qua Serial
     */
    fun write(data: ByteArray, timeout: Int = 1000): Int {
        val port = usbSerialPort ?: return -1
        return try {
            port.write(data, timeout)
            data.size
        } catch (e: IOException) {
            Log.e(TAG, "Lỗi ghi dữ liệu serial: ${e.message}")
            -1
        }
    }

    fun disconnect() {
        try {
            usbIoManager?.listener = null
            usbIoManager?.stop()
            usbIoManager = null
        } catch (e: Exception) {}

        try {
            usbSerialPort?.close()
            usbSerialPort = null
        } catch (e: Exception) {}

        try {
            usbConnection?.close()
            usbConnection = null
        } catch (e: Exception) {}
    }

    // Callbacks từ SerialInputOutputManager
    override fun onNewData(data: ByteArray) {
        onDataReceived(data)
    }

    override fun onRunError(e: Exception) {
        Log.e(TAG, "Serial IO Manager Error: ${e.message}")
        onStatusChanged("Lỗi luồng Serial USB: ${e.message}", false)
    }
}
