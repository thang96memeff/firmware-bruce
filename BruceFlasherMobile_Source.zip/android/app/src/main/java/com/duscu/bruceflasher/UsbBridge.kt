package com.duscu.bruceflasher

import android.util.Base64
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

/**
 * UsbBridge: Cầu nối JavaScriptInterface giữa Web UI và Native Android
 */
class UsbBridge(
    private val activity: MainActivity,
    private val webView: WebView,
    private val usbSerialManager: UsbSerialManager,
    private val firmwareDownloader: FirmwareDownloader
) {
    private val TAG = "UsbBridge"
    private var currentTempFile: File? = null

    /**
     * Kiểm tra trạng thái kết nối USB
     */
    @JavascriptInterface
    fun isConnected(): Boolean {
        return usbSerialManager.isConnected()
    }

    /**
     * Lấy số lượng thiết bị USB Serial khả dụng đang cắm vào OTG
     */
    @JavascriptInterface
    fun getAttachedDevicesCount(): Int {
        return usbSerialManager.getAvailableDriversCount()
    }

    /**
     * Lấy thông tin thiết bị đang cắm (JSON)
     */
    @JavascriptInterface
    fun getAttachedDeviceInfo(): String {
        return usbSerialManager.getAttachedDeviceInfoJson()
    }

    /**
     * Bắt đầu kết nối cổng USB OTG
     */
    @JavascriptInterface
    fun connect(baudRate: Int) {
        activity.runOnUiThread {
            val driver = usbSerialManager.findAvailableDriver()
            if (driver == null) {
                notifyWeb("onPortError", "Không tìm thấy thiết bị USB nào cắm vào điện thoại. Hãy cắm cáp OTG và thử lại.")
                return@runOnUiThread
            }

            usbSerialManager.requestPermission(driver) { granted ->
                if (granted) {
                    val success = usbSerialManager.open(driver, baudRate)
                    if (success) {
                        notifyWeb("onPortConnected", "Đã kết nối thiết bị qua USB OTG thành công.")
                    } else {
                        notifyWeb("onPortError", "Mở cổng USB thất bại.")
                    }
                } else {
                    notifyWeb("onPortError", "Người dùng từ chối cấp quyền truy cập USB.")
                }
            }
        }
    }

    /**
     * Ngắt kết nối USB
     */
    @JavascriptInterface
    fun disconnect() {
        activity.runOnUiThread {
            activity.setKeepScreenOn(false)
            usbSerialManager.disconnect()
            notifyWeb("onPortDisconnected", "Đã ngắt kết nối USB.")
        }
    }

    /**
     * Điều khiển giữ màn hình luôn sáng từ Web UI
     */
    @JavascriptInterface
    fun setKeepScreenOn(enable: Boolean) {
        activity.setKeepScreenOn(enable)
    }

    /**
     * Đổi tốc độ baudrate
     */
    @JavascriptInterface
    fun setBaudRate(baudRate: Int): Boolean {
        return usbSerialManager.setBaudRate(baudRate)
    }

    /**
     * Điều khiển tín hiệu DTR/RTS
     */
    @JavascriptInterface
    fun setDTR(state: Boolean) {
        usbSerialManager.setDTR(state)
    }

    @JavascriptInterface
    fun setRTS(state: Boolean) {
        usbSerialManager.setRTS(state)
    }

    /**
     * Reset bo mạch
     */
    @JavascriptInterface
    fun resetBoard() {
        usbSerialManager.resetBoard()
        notifyWeb("onResetDone", "Đã phát xung khởi động lại thiết bị.")
    }

    /**
     * Gửi dữ liệu Base64 qua USB Serial
     */
    @JavascriptInterface
    fun writeBase64(base64Data: String): Int {
        return try {
            val bytes = Base64.decode(base64Data, Base64.NO_WRAP)
            usbSerialManager.write(bytes)
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi giải mã base64: ${e.message}")
            -1
        }
    }

    /**
     * TỰ ĐỘNG TẢI FIRMWARE VỀ BỘ NHỚ ĐỆM TẠM KHI BẤM NẠP
     */
    @JavascriptInterface
    fun startDownloadAndPrepare(boardId: String, binFileName: String) {
        CoroutineScope(Dispatchers.Main).launch {
            // Giữ màn hình luôn sáng khi bắt đầu quá trình nạp
            activity.setKeepScreenOn(true)
            notifyWeb("onDownloadStart", "Bắt đầu tải firmware cho bo mạch $boardId...")

            val result = firmwareDownloader.downloadFirmware(boardId, binFileName) { percent, read, total ->
                notifyWeb("onDownloadProgress", "$percent,$read,$total")
            }

            result.onSuccess { tempFile ->
                currentTempFile = tempFile
                val fileSize = tempFile.length()
                Log.d(TAG, "Firmware sẵn sàng để nạp: ${tempFile.absolutePath} ($fileSize bytes)")
                notifyWeb("onDownloadSuccess", "$fileSize")
            }.onFailure { err ->
                activity.setKeepScreenOn(false)
                Log.e(TAG, "Lỗi tải firmware: ${err.message}")
                notifyWeb("onDownloadError", err.message ?: "Không rõ nguyên nhân")
            }
        }
    }

    /**
     * Đọc khối dữ liệu từ file firmware tạm để nạp từng phần
     */
    @JavascriptInterface
    fun readFirmwareChunkBase64(offset: Long, length: Int): String {
        val file = currentTempFile ?: return ""
        return try {
            file.inputStream().use { stream ->
                stream.skip(offset)
                val buffer = ByteArray(length)
                val read = stream.read(buffer)
                if (read > 0) {
                    val actualData = if (read == length) buffer else buffer.copyOf(read)
                    Base64.encodeToString(actualData, Base64.NO_WRAP)
                } else {
                    ""
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi đọc chunk firmware: ${e.message}")
            ""
        }
    }

    /**
     * TỰ ĐỘNG XÓA SẠCH FILE FIRMWARE SAU KHI NẠP HOÀN TẤT HOẶC KHI HUỶ/LỖI
     * Theo đúng chỉ đạo của Chủ tịch Thăng.
     */
    @JavascriptInterface
    fun finishAndCleanupFirmware() {
        activity.setKeepScreenOn(false)
        val file = currentTempFile
        if (file != null) {
            val deleted = firmwareDownloader.deleteTempFirmware(file)
            currentTempFile = null
            Log.d(TAG, "[TỰ ĐỘNG XÓA] File firmware đã được xóa sạch khỏi bộ nhớ: $deleted")
        }
        firmwareDownloader.cleanAllTempFiles()
        notifyWeb("onFirmwareCleaned", "Đã tự động xóa sạch file firmware tạm khỏi bộ nhớ.")
    }

    /**
     * Đọc trực tiếp tệp sơ đồ chân JSON từ assets để hoạt động Offline 100% không cần Internet
     */
    @JavascriptInterface
    fun getSodoJson(boardId: String): String {
        return try {
            activity.assets.open("www/sodo/$boardId.json").bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            try {
                activity.assets.open("www/sodo/${boardId.lowercase()}.json").bufferedReader().use { it.readText() }
            } catch (e2: Exception) {
                Log.w(TAG, "Không tìm thấy sơ đồ chân offline cho: $boardId")
                ""
            }
        }
    }

    /**
     * Mở bộ chọn tệp Native SAF của Android (chọn file .bin từ điện thoại)
     */
    @JavascriptInterface
    fun openLocalFilePicker() {
        activity.runOnUiThread {
            activity.launchLocalFileChooser()
        }
    }

    /**
     * Đọc khối dữ liệu Base64 từ file firmware ngoài đã chọn
     */
    @JavascriptInterface
    fun readLocalPickedChunkBase64(offset: Long, length: Int): String {
        return activity.readLocalPickedChunkBase64(offset, length)
    }

    /**
     * Hủy/dọn dẹp file ngoài tạm thời khi hoàn tất hoặc bỏ chọn
     */
    @JavascriptInterface
    fun cleanupLocalPickedFile() {
        activity.cleanupLocalPickedFile()
    }

    /**
     * Báo cho Web UI biết file ngoài đã được chọn thành công
     */
    fun notifyLocalFilePicked(fileName: String, fileSize: Long) {
        activity.runOnUiThread {
            val safeName = fileName.replace("'", "\\'").replace("\"", "\\\"")
            webView.evaluateJavascript("window.onLocalFilePickedFromNative && window.onLocalFilePickedFromNative('$safeName', $fileSize);", null)
        }
    }

    /**
     * Đọc danh sách bo mạch từ assets/www/boards.json khi thiết bị ở chế độ ngoại tuyến (Offline)
     */
    @JavascriptInterface
    fun getBoardsJson(): String {
        return try {
            activity.assets.open("www/boards.json").bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            Log.w(TAG, "Không thể đọc www/boards.json từ assets: ${e.message}")
            ""
        }
    }

    /**
     * Bắn sự kiện ngược lại JavaScript trong WebView
     */
    fun notifyWeb(functionName: String, param: String) {
        activity.runOnUiThread {
            val escapedParam = param.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "")
            webView.evaluateJavascript("window.$functionName && window.$functionName('$escapedParam');", null)
        }
    }

    /**
     * Truyền dữ liệu Serial nhận được lên WebView
     */
    fun sendSerialDataToWeb(bytes: ByteArray) {
        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        activity.runOnUiThread {
            webView.evaluateJavascript("window.onSerialDataReceived && window.onSerialDataReceived('$base64');", null)
        }
    }
}
