package com.duscu.bruceflasher

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * MainActivity: Điều khiển giao diện chính của ứng dụng Bruce Flasher Mobile
 * - Quản lý WebView và cầu nối JavaScriptInterface
 * - Xử lý sự kiện cắm/rút cáp USB OTG (ACTION_USB_DEVICE_ATTACHED / ACTION_USB_DEVICE_DETACHED)
 * - Điều khiển giữ màn hình luôn sáng khi đang nạp firmware (FLAG_KEEP_SCREEN_ON)
 */
class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"
    private lateinit var webView: WebView
    private lateinit var usbSerialManager: UsbSerialManager
    private lateinit var firmwareDownloader: FirmwareDownloader
    private lateinit var usbBridge: UsbBridge

    /**
     * Bộ chọn tệp hệ thống cho WebView (hỗ trợ nhập file .bin từ điện thoại)
     */
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    private val filePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri = result.data?.data
            val clipData = result.data?.clipData
            val results: Array<Uri>? = when {
                clipData != null && clipData.itemCount > 0 -> {
                    Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                }
                uri != null -> arrayOf(uri)
                else -> null
            }
            fileUploadCallback?.onReceiveValue(results)
        } else {
            fileUploadCallback?.onReceiveValue(null)
        }
        fileUploadCallback = null
    }

    /**
     * Bộ lắng nghe sự kiện cắm/rút thiết bị USB OTG theo thời gian thực
     */
    private val usbEventReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    Log.d(TAG, "Sự kiện cắm cáp USB OTG (Broadcast)")
                    handleUsbAttachedIntent(intent)
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    Log.d(TAG, "Sự kiện rút cáp USB OTG (Broadcast)")
                    handleUsbDetached()
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Đồng bộ màu thanh trạng thái và điều hướng chuẩn phong cách Liquid Glass Aqua (#BCE3F5)
        window.statusBarColor = Color.parseColor("#BCE3F5")
        window.navigationBarColor = Color.parseColor("#BCE3F5")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        webView = WebView(this)
        setContentView(webView)

        firmwareDownloader = FirmwareDownloader(this)
        firmwareDownloader.cleanAllTempFiles() // Dọn các file tạm cũ khi khởi động

        usbSerialManager = UsbSerialManager(
            context = this,
            onDataReceived = { bytes ->
                usbBridge.sendSerialDataToWeb(bytes)
            },
            onStatusChanged = { message, isConnected ->
                usbBridge.notifyWeb(if (isConnected) "onPortConnected" else "onPortDisconnected", message)
            }
        )

        usbBridge = UsbBridge(this, webView, usbSerialManager, firmwareDownloader)

        setupWebView()
        webView.loadUrl("file:///android_asset/www/index.html")

        registerUsbReceivers()

        // Xử lý Intent nếu ứng dụng được kích hoạt trực tiếp từ việc cắm cáp OTG
        handleUsbAttachedIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleUsbAttachedIntent(intent)
    }

    /**
     * Đăng ký lắng nghe sự kiện cắm rút USB OTG
     */
    private fun registerUsbReceivers() {
        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbEventReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbEventReceiver, filter)
        }
    }

    /**
     * Xử lý khi thiết bị USB OTG được cắm vào
     */
    private fun handleUsbAttachedIntent(intent: Intent?) {
        if (intent?.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) {
            val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            }
            val deviceName = device?.productName ?: device?.deviceName ?: "Thiết bị USB OTG"
            Toast.makeText(this, "Đã cắm thiết bị: $deviceName", Toast.LENGTH_SHORT).show()
            usbBridge.notifyWeb("onUsbAttached", "Đã phát hiện thiết bị cắm vào: $deviceName")
        }
    }

    /**
     * Xử lý khi cáp USB OTG bị rút ra
     */
    private fun handleUsbDetached() {
        setKeepScreenOn(false)
        Toast.makeText(this, "Đã ngắt kết nối thiết bị USB OTG", Toast.LENGTH_SHORT).show()
        usbBridge.notifyWeb("onUsbDetached", "Thiết bị USB OTG đã ngắt kết nối.")
    }

    /**
     * Điều khiển giữ màn hình luôn sáng khi đang nạp code (FLAG_KEEP_SCREEN_ON)
     * Ngăn ngừa việc tắt màn hình làm ngắt quãng quá trình truyền nạp firmware
     */
    fun setKeepScreenOn(enable: Boolean) {
        runOnUiThread {
            if (enable) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                Log.d(TAG, "Đã bật FLAG_KEEP_SCREEN_ON (Giữ màn hình luôn sáng)")
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                Log.d(TAG, "Đã tắt FLAG_KEEP_SCREEN_ON")
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.setBackgroundColor(Color.TRANSPARENT)
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.allowFileAccessFromFileURLs = true
        settings.allowUniversalAccessFromFileURLs = true
        settings.databaseEnabled = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                mWebView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback

                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                        "application/octet-stream",
                        "application/macbinary",
                        "application/x-binary",
                        "*/*"
                    ))
                }
                return try {
                    filePickerLauncher.launch(Intent.createChooser(intent, "Chọn file firmware (.bin)"))
                    true
                } catch (e: Exception) {
                    Log.e(TAG, "Lỗi mở bộ chọn tệp: ${e.message}")
                    fileUploadCallback?.onReceiveValue(null)
                    fileUploadCallback = null
                    false
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {}

        // Gắn Native Bridge vào JavaScript dưới biến toàn cục `window.AndroidUSB`
        webView.addJavascriptInterface(usbBridge, "AndroidUSB")
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(usbEventReceiver)
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi unregister receiver: ${e.message}")
        }
        setKeepScreenOn(false)
        firmwareDownloader.cleanAllTempFiles()
        usbSerialManager.destroy()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
