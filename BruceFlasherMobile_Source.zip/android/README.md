# Bruce Flasher Mobile (DUSCU Flasher Android) v1.0.1 🚀📱

**Ứng dụng Android chính thức phục vụ cộng đồng Bruce Pentest Firmware**  
*Giải pháp hoàn hảo giúp anh em không có máy tính (PC) vẫn có thể nạp firmware dễ dàng và nhanh chóng cho tất cả 35 dòng bo mạch ESP32 / ESP32-S3 / ESP32-C5 / BW16 chỉ bằng một sợi cáp USB OTG cắm trực tiếp vào điện thoại!*

---

## ⬇️ TẢI XUỐNG ỨNG DỤNG (FILE APK THÀNH PHẨM):

Anh em có thể tải trực tiếp file cài đặt APK v1.0.1 đã được hệ thống CI/CD tự động đóng gói:

1. **Tải từ mục Releases chính thức (Khuyên dùng):**
   - Truy cập: [Bruce Flasher Mobile Releases](https://github.com/thang96memeff/bruce-duscu/releases/tag/android-v1.0.1)
   - Tải file: `BruceFlasherMobile-v1.0.1.apk` (hoặc từ kho firmware-bruce) và cài đặt trực tiếp vào điện thoại Android.
2. **Tải từ GitHub Actions Artifacts:**
   - Vào tab **Actions** -> Chọn workflow **Build Bruce Flasher Android APK** -> Tải gói artifact **BruceFlasherMobile-APK**.

---

## 🌟 TÍNH NĂNG NỔI BẬT TRÊN BẢN v1.0.1 THEO CHỈ THỊ CỦA CHỦ TỊCH THĂNG:

1. **Bảng Báo Nhật Ký Live Terminal & Live Log Ticker:**
   - Bổ sung phím tắt chuyển nhanh `[Xem Nhật Ký Log]` và `[Xem Sơ Đồ Chân]` ngay trên giao diện di động.
   - Hệ thống tự động chuyển thẳng sang tab **Nhật Ký (sys)** ngay khi bấm Kết nối, Nạp code hoặc Xóa chip để người dùng theo dõi sát sao từng dòng log nạp trong thời gian thực.
2. **Kích Hoạt Chọn File Ngoài (.bin) Trực Tiếp Từ Điện Thoại:**
   - Tích hợp bộ chọn file Native `onShowFileChooser` trong `MainActivity.kt` (`WebChromeClient`).
   - Người dùng có thể bấm nút **Nạp tệp ngoài** để mở trình duyệt file hệ thống của Android (bộ nhớ máy, Thư mục Tải về, Zalo, Google Drive...) và nạp bất kỳ file `.bin` tùy chỉnh nào.
3. **Phân Nhóm Riêng Biệt ESP32 & BW16 Realtek (5GHz):**
   - Tách biệt rõ ràng giữa hệ sinh thái chip ESP32 (S3/C5/Classic) và Module hai băng tần Realtek **BW16 (RTL8720DN 2.4/5GHz)**.
   - Thêm nút lọc nhanh danh mục và nhóm danh sách chọn bo mạch riêng cho BW16 kèm chú thích nạp qua UART 115200.
4. **Sửa Lỗi Nhận Diện Sai Cổng USB (Chống Báo Ảo):**
   - Tích hợp kiểm tra thiết bị phần cứng thực tế qua `getAttachedDevicesCount()` và `getAttachedDeviceInfo()`.
   - Tuyệt đối không giả lập cổng ESP32 Native khi chưa cắm thiết bị; hiện cảnh báo hướng dẫn cắm cáp OTG và bật OTG trong Cài đặt nếu chưa phát hiện cổng.
5. **Cơ Chế Tự Động Tải & TỰ ĐỘNG XÓA SẠCH FILE TẠM (Zero-Footprint Storage Engine):**
   - Tự động kiểm tra dung lượng trống (tối thiểu `>= 20MB`), tải firmware từ 5 mirror CDN.
   - **Cam kết tuyệt đối bảo vệ bộ nhớ người dùng:** Ngay khi nạp xong 100% hoặc khi gặp bất kỳ sự cố nào, toàn bộ file `.bin` tạm thời trong bộ nhớ đệm sẽ **BỊ XÓA SẠCH HOÀN TOÀN NGAY LẬP TỨC** (`file.delete()`, `cleanAllTempFiles()`).
6. **Tra cứu Sơ đồ chân Offline 100% (37 file JSON 8 module chuẩn)** kết hợp cơ chế Stale-While-Revalidate tự động làm mới khi máy chủ cập nhật.
7. **Hỗ trợ toàn diện 100% chip nạp USB OTG:** CH340, CP210x, FTDI, PL2303, Native USB CDC VID `0x303A` (ESP32-S3/C5).
8. **Giao diện Ultra-Translucent Liquid Glass System:** Kính mờ xuyên thấu Aqua `#BCE3F5`, hiệu ứng WebGL Caustics và giữ màn hình luôn sáng (`FLAG_KEEP_SCREEN_ON`).

---

## 📁 CẤU TRÚC DỰ ÁN ANDROID (`android/`):

```text
android/
├── build.gradle               # Gradle build script tổng
├── settings.gradle            # Khai báo module :app và kho lưu trữ dependencies
├── gradle.properties          # Tối ưu hóa JVM heap 2GB & AndroidX
├── README.md                  # Cẩm nang hướng dẫn sử dụng & đóng gói APK
├── app/
│   ├── build.gradle           # Cấu hình SDK 34, thư viện usb-serial-for-android & OkHttp
│   └── src/main/
│       ├── AndroidManifest.xml# Khai báo quyền USB Host, Internet, intent-filter OTG
│       ├── java/com/duscu/bruceflasher/
│       │   ├── MainActivity.kt        # Khởi tạo WebView, giữ màn hình sáng & nhận diện cắm/rút OTG
│       │   ├── UsbSerialManager.kt    # Quản lý driver USB OTG (CH340/CP210x/CDC/FTDI)
│       │   ├── FirmwareDownloader.kt  # Tải firmware đa mirror & TỰ ĐỘNG XÓA SẠCH file tạm
│       │   └── UsbBridge.kt           # Cầu nối JavaScriptInterface Native Bridge & Sodo Offline
│       ├── res/
│       │   ├── xml/device_filter.xml  # Bộ lọc nhận diện tự động cắm cáp USB cho các dòng chip
│       │   └── values/                # Strings, colors Aqua #BCE3F5, theme Liquid Glass
│       └── assets/www/
│           ├── index.html             # Giao diện Flasher Mobile Liquid Glass y chang Web Flasher
│           ├── boards.json            # Danh mục 35 bo mạch hỗ trợ nạp
│           ├── sodo/                  # 37 file JSON sơ đồ chân 8 module chuẩn
│           └── js/
│               └── android_usb_transport.js # Cầu nối Web Serial Polyfill & Zero-Footprint Engine
```

---

## 📱 CẨM NĂNG BẬT USB OTG & QUY TRÌNH NẠP TRÊN ĐIỆN THOẠI:

### ⚠️ Bước 0: Bật tính năng USB OTG theo từng hãng máy (BẮT BUỘC)

Một số dòng điện thoại Android có tính năng tiết kiệm pin tự động ngắt kết nối OTG sau 10 phút hoặc yêu cầu bật thủ công:

| Hãng điện thoại | Đường dẫn bật USB OTG trong Cài đặt | Lưu ý đặc biệt |
| :--- | :--- | :--- |
| **OPPO / Realme / OnePlus** *(ColorOS / Realme UI / OxygenOS)* | `Cài đặt` -> `Cài đặt bổ sung` (hoặc `Hệ thống`) -> Bật **Kết nối OTG** | Tự tắt sau 10 phút nếu không cắm cáp. Cần bật lại khi sử dụng. |
| **Vivo / iQOO** *(Funtouch OS / OriginOS)* | `Cài đặt` -> `Bluetooth và thiết bị khác` (hoặc `Mạng`) -> Bật **OTG** | Tự tắt sau 5-10 phút nếu không có thiết bị truyền dữ liệu. |
| **Xiaomi / Redmi / POCO** *(MIUI / HyperOS)* | Tự động bật khi cắm cáp OTG | Nếu không nhận, kiểm tra lại cáp dữ liệu hoặc bật `Gỡ lỗi USB` trong `Tùy chọn nhà phát triển`. |
| **Samsung Galaxy** *(One UI)* | Mặc định tự động nhận diện thiết bị USB | Khuyến nghị sử dụng đầu chuyển OTG chính hãng đi kèm máy hoặc chuẩn Type-C to Type-C. |
| **Google Pixel / Motorola / Nokia** | Mặc định tự động nhận diện thiết bị USB | Tự động kích hoạt driver USB Host khi cắm cáp. |
| **Huawei / Honor** *(EMUI / MagicOS)* | `Cài đặt` -> `Tính năng trợ năng` -> Bật **OTG** (hoặc tự nhận) | Hỗ trợ tốt các dòng cáp OTG tiêu chuẩn. |
| **TECNO / Infinix** *(HiOS / XOS)* | `Cài đặt` -> `Thêm kết nối` -> Bật **OTG** | Cần bật thủ công trước khi cắm cáp vào vi điều khiển. |

---

### 🔌 Hướng dẫn các bước nạp Firmware chi tiết:

1. **Chuẩn bị phụ kiện:**
   - **01 sợi cáp dữ liệu (Data Cable):** Rất nhiều sợi cáp giá rẻ trên thị trường chỉ có 2 dây nguồn phục vụ sạc pin (không có dây Data D+/D-), ứng dụng sẽ không thể nhận diện được mạch. Hãy chắc chắn sử dụng sợi cáp truyền được dữ liệu với máy tính.
   - **01 đầu chuyển USB OTG:** Chuẩn Type-C sang Type-A hoặc sợi cáp hai đầu Type-C to Type-C hỗ trợ OTG.
2. **Cắm kết nối mạch:**
   - Cắm đầu OTG vào điện thoại Android, đầu còn lại cắm vào cổng USB của bo mạch ESP32.
3. **Cấp quyền truy cập USB Host:**
   - Hệ thống Android sẽ ngay lập tức bật hộp thoại thông báo:
     > *"Cho phép DUSCU FLASHER truy cập thiết bị USB?"*
   - Tích chọn ô: **"Luôn mở DUSCU FLASHER khi thiết bị này được kết nối"** và bấm **OK / Cho phép**.
4. **Đưa vi điều khiển về Bootloader Mode (Nếu mạch không nhận diện tự động):**
   - Với các dòng ESP32 thông thường: Nhấn giữ nút **BOOT** (hoặc kéo GPIO 0 xuống GND), bấm nhả nút **EN / RST**, sau đó nhả nút BOOT.
   - Với các dòng ESP32-S3 / C5 dùng cổng USB Native: Giữ nút **BOOT** trong khi cắm cáp USB vào điện thoại để máy nhận đúng chip CDC VID `0x303A`.
5. **Chọn bo mạch & Tra cứu sơ đồ chân:**
   - Tìm kiếm và chọn đúng bo mạch của anh em (ví dụ: `Cardputer`, `T-Deck`, `CYD-2432S028`, `Marauder-Mini`, `BW16`, ...).
   - Chuyển sang tab **"SƠ ĐỒ CHÂN (PINOUT)"** để xem chi tiết đấu nối 8 module (Màn hình, Nút bấm, Thẻ nhớ, NRF24, CC1101, GPS, BW16, IR).
6. **Tiến hành nạp:**
   - Bấm nút **"NẠP FIRMWARE (FLASH)"**:
     + Ứng dụng tự động kết nối kéo firmware về cache tạm.
     + Thực hiện xóa flash (Erase) và ghi từng khối dữ liệu nhị phân với thanh tiến trình trực quan.
     + Khi đạt **100% Hoàn tất**, hệ thống phát xung Reset khởi động vi điều khiển và **ngay lập tức xóa sạch file `.bin` tạm thời trong máy**.
   - Bấm **"MỞ SERIAL MONITOR"** để xem log khởi động của firmware Bruce Pentest hoặc rút cáp trải nghiệm ngay!

---

## 🛠 HƯỚNG DẪN TỰ BIÊN DỊCH VÀ ĐÓNG GÓI APK (.APK):

### Cách 1: Tự động qua GitHub Actions CI/CD (Khuyên dùng)
Hệ thống CI/CD đã được cấu hình sẵn tại `.github/workflows/build_android_apk.yml`.  
Mỗi khi có commit đẩy vào thư mục `android/` trên nhánh `main`, máy chủ Ubuntu của GitHub Actions sẽ tự động biên dịch và tạo bản phát hành tại mục **Releases** với tag `android-v1.0.0`.

### Cách 2: Sử dụng dòng lệnh Terminal (Linux / macOS / Windows)
Yêu cầu máy tính có cài sẵn **Java 17 (OpenJDK 17)**:

```bash
cd android

# Cấp quyền thực thi và biên dịch Debug APK
gradle assembleDebug --stacktrace

# Hoặc biên dịch Release APK
gradle assembleRelease
```

File APK thành phẩm nằm tại:  
`android/app/build/outputs/apk/debug/app-debug.apk`

### Cách 3: Sử dụng Android Studio
1. Mở **Android Studio** (Bản Jellyfish / Koala hoặc mới hơn).
2. Chọn `Open` -> Trỏ đến thư mục `bruce-duscu/android`.
3. Chờ Gradle tự động tải dependencies từ kho Google Maven và JitPack.
4. Chọn menu `Build` -> `Build Bundle(s) / APK(s)` -> `Build APK(s)`.
5. Bấm `locate` để lấy file `app-debug.apk` cài đặt trực tiếp lên điện thoại.

---

## 🛡️ BẢN QUYỀN & CỘNG ĐỒNG:
- Dự án phát triển bởi **Chủ tịch Thăng** và **Cụm 5 Máy chủ phân tán Bruce Core Team**.
- Sử dụng các thư viện mã nguồn mở:
  - `usb-serial-for-android` (mik3y) – Lõi điều khiển driver USB Host OTG.
  - `esptool-js` (Espressif Systems) – Giao thức nạp ROM bootloader vi điều khiển.
  - `OkHttp 4` (Square) – Tải firmware đa mirror tốc độ cao.
  - `Tailwind CSS & WebGL Caustics` – Hiệu ứng giao diện Liquid Glass Aqua `#BCE3F5`.
