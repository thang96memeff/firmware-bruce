@echo off
setlocal EnableDelayedExpansion
title TOOL XOA SACH FLASH & NAP LAI - BW16 FOR BRUCE
color 0E

cd /d "%~dp0"

echo =====================================================================
echo       TOOL XOA SACH FLASH & NAP MOI - REALTEK BW16 (RTL8720DN)
echo                   DU AN: BW16 FOR BRUCE DEAUTHER
echo =====================================================================
echo.
echo  CHU Y: Day la che do nạp an toan nhat. Tool se xoa toan bo Flash cu
echo  va nap moi hoan toan de dam bao khong bi xung dot du lieu cu!
echo =====================================================================
echo.

if not exist "upload_image_tool_windows.exe" (
    color 0C
    echo [LOI] Khong tim thay file upload_image_tool_windows.exe!
    pause
    exit /b 1
)

if not exist "km0_km4_image2.bin" (
    color 0C
    echo [LOI] Khong tim thay file firmware km0_km4_image2.bin!
    pause
    exit /b 1
)

echo [*] Danh sach cong COM dang ket noi tren may tinh:
echo ---------------------------------------------------------------------
powershell -NoProfile -Command "$p = [System.IO.Ports.SerialPort]::GetPortNames(); if ($p.Count -eq 0) { Write-Host '  (Chua phat hien cong COM nao. Hay cam cap USB vao may)' } else { $p | ForEach-Object { Write-Host ('  -> Cong COM: ' + $_) } }"
echo ---------------------------------------------------------------------
echo.

:CHON_COM
set "USER_COM="
set /p USER_COM="-> Nhap so cong COM (vi du nhap 3 hoac COM3): "
if not defined USER_COM (
    echo Vui long nhap so cong COM!
    goto CHON_COM
)

set "TARGET_COM=%USER_COM: =%"
set "PREFIX=%TARGET_COM:~0,3%"
if /i not "%PREFIX%"=="COM" (
    set "TARGET_COM=COM%TARGET_COM%"
)

echo.
echo [*] Cong COM da chon: %TARGET_COM%
echo.

echo =====================================================================
echo         HUONG DAN DUA BW16 VAO CHE DO NAP (DOWNLOAD MODE)
echo =====================================================================
echo  1. Nhan va GIU nut BURN (hoac noi chan Log_RX / PA08 xuong GND)
echo  2. Nhan nut RST (Reset) mot lan roi THA RST ra
echo  3. Sau do THA nut BURN ra
echo.
echo  Tien trinh se:
echo   - Xoa sach toan bo 2MB Flash cu (Xoa sach OTA2, phan vung rac, boot cu)
echo   - Nap moi hoan toan Bootloader va Firmware BW16 FOR BRUCE
echo.
echo  Khi san sang, nhan phim bat ky de bat dau...
echo =====================================================================
pause >nul

echo.
echo [*] Dang thuc hien XOA SACH FLASH & NAP MOI vao %TARGET_COM%...
echo [*] Vui long KHONG rut cap USB trong luc dang nap!
echo ---------------------------------------------------------------------

upload_image_tool_windows.exe . %TARGET_COM% AMEBA Disable Enable 1500000

if %ERRORLEVEL% equ 0 goto NAP_THANH_CONG

echo.
echo [!] Thu lai o toc do on dinh 921600 baud...
upload_image_tool_windows.exe . %TARGET_COM% AMEBA Disable Enable 921600
if %ERRORLEVEL% equ 0 goto NAP_THANH_CONG
goto NAP_THAT_BAI

:NAP_THANH_CONG
echo ---------------------------------------------------------------------
color 0A
echo.
echo =====================================================================
echo        [OK] XOA SACH FLASH VA NAP MOI THANH CONG 100%!
echo =====================================================================
echo  Nhan nut RST tren board BW16 de thiet bi khoi dong lai.
echo =====================================================================
goto KET_THUC

:NAP_THAT_BAI
echo ---------------------------------------------------------------------
color 0C
echo.
echo =====================================================================
echo                 [X] NAP THAT BAI HOAC CO LOI XAY RA!
echo =====================================================================
echo  Vui long kiem tra lai:
echo   1. Da chon dung cong COM chua? (Kiem tra trong Device Manager)
echo   2. Da thao tac Giu BURN + Bam RST truoc khi nap chua?
echo   3. Day tin hieu TX/RX da cam dung chua (TX board -^> RX mach nap)?
echo   4. Thu doi cong USB khac hoac cap USB chat luong tot hon.
echo =====================================================================
goto KET_THUC

:KET_THUC
echo.
pause
