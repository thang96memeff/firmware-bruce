@echo off
setlocal EnableDelayedExpansion
title TOOL NAP FIRMWARE BW16 FOR BRUCE - REALTEK RTL8720DN
color 0B

cd /d "%~dp0"

echo =====================================================================
echo       TOOL NAP FIRMWARE TU DONG - REALTEK BW16 (RTL8720DN)
echo                  DU AN: BW16 FOR BRUCE DEAUTHER
echo =====================================================================
echo.

if not exist "upload_image_tool_windows.exe" (
    color 0C
    echo [LOI] Khong tim thay file upload_image_tool_windows.exe!
    echo Vui long giai nen toan bo file trong package zip truoc khi chay.
    echo.
    pause
    exit /b 1
)

if not exist "km0_km4_image2.bin" (
    color 0C
    echo [LOI] Khong tim thay file firmware km0_km4_image2.bin!
    echo.
    pause
    exit /b 1
)

echo [*] Danh sach cong COM dang ket noi tren may tinh:
echo ---------------------------------------------------------------------
powershell -NoProfile -Command "$p = [System.IO.Ports.SerialPort]::GetPortNames(); if ($p.Count -eq 0) { Write-Host '  (Chua phat hien cong COM nao. Hay cam cap USB vao may)' } else { $p | ForEach-Object { Write-Host ('  -> Cong COM: ' + $_) } }"
echo ---------------------------------------------------------------------
echo.

:CHON_COM
set "USER_COM="
set /p USER_COM="-> Nhap so cong COM (vi du nhap 3 hoac COM3): "
if not defined USER_COM (
    echo Vui long nhap so cong COM!
    goto CHON_COM
)

set "TARGET_COM=%USER_COM: =%"
set "PREFIX=%TARGET_COM:~0,3%"
if /i not "%PREFIX%"=="COM" (
    set "TARGET_COM=COM%TARGET_COM%"
)

echo.
echo [*] Cong COM da chon: %TARGET_COM%
echo.

echo =====================================================================
echo         HUONG DAN DUA BW16 VAO CHE DO NAP (DOWNLOAD MODE)
echo =====================================================================
echo  1. Nhan va GIU nut BURN (hoac noi chan Log_RX / PA08 xuong GND)
echo  2. Nhan nut RST (Reset) mot lan roi THA RST ra
echo  3. Sau do THA nut BURN ra
echo.
echo  Khi san sang, nhan phim bat ky de bat dau nap firmware...
echo =====================================================================
pause >nul

echo.
echo [*] Dang nap firmware vao %TARGET_COM% (Baudrate: 1500000)...
echo [*] Vui long KHONG rut cap USB trong luc dang nap!
echo ---------------------------------------------------------------------

upload_image_tool_windows.exe . %TARGET_COM% AMEBA Disable Disable 1500000

if %ERRORLEVEL% equ 0 goto NAP_THANH_CONG
goto NAP_THAT_BAI

:NAP_THANH_CONG
echo ---------------------------------------------------------------------
color 0A
echo.
echo =====================================================================
echo                    [OK] NAP FIRMWARE THANH CONG!
echo =====================================================================
echo  Hay nhan nut RST tren board BW16 de thiet bi khoi dong lai.
echo.
echo  * MEU QUAN TRONG:
echo    Neu board tung nap firmware khac hoac gap loi khoi dong:
echo    Hay chay file: "2_Xoa_Sach_Flash_Va_Nap_Lai.bat" de xoa sach toan bo
echo    du lieu Flash cu va nap moi tu dau!
echo =====================================================================
goto KET_THUC

:NAP_THAT_BAI
echo ---------------------------------------------------------------------
color 0C
echo.
echo =====================================================================
echo                 [X] NAP THAT BAI HOAC CO LOI XAY RA!
echo =====================================================================
echo  Vui long kiem tra lai:
echo   1. Da chon dung cong COM chua? (Kiem tra trong Device Manager)
echo   2. Da thao tac Giu BURN + Bam RST truoc khi nap chua?
echo   3. Day tin hieu TX/RX da cam dung chua (TX board -^> RX mach nap)?
echo =====================================================================
goto KET_THUC

:KET_THUC
echo.
pause
