@echo off
setlocal EnableDelayedExpansion
title TOOL XOA TRANG BO NHO FLASH BW16 (ERASE ONLY) - REALTEK RTL8720DN
color 0C

cd /d "%~dp0"

echo =====================================================================
echo         TOOL XOA TRANG TOAN BO FLASH (ERASE ONLY - CHIP BLANK)
echo                REALTEK BW16 (RTL8720DN) AMBA D
echo =====================================================================
echo.
echo  CHU Y: Tool nay se xoa trang 100%% bo nho Flash (dua ve trang thai rong 0xFF).
echo  Sau khi xoa trang, ban can chay lai file "1_Nap_Firmware_BW16.bat"
echo  hoac "2_Xoa_Sach_Flash_Va_Nap_Lai.bat" de nap firmware vao board!
echo =====================================================================
echo.

if not exist "upload_image_tool_windows.exe" (
    color 0C
    echo [LOI] Khong tim thay file upload_image_tool_windows.exe!
    pause
    exit /b 1
)

if not exist "imgtool_flashloader_amebad.bin" (
    color 0C
    echo [LOI] Khong tim thay file imgtool_flashloader_amebad.bin!
    pause
    exit /b 1
)

echo [*] Danh sach cong COM dang ket noi tren may tinh:
echo ---------------------------------------------------------------------
powershell -NoProfile -Command "$p = [System.IO.Ports.SerialPort]::GetPortNames(); if ($p.Count -eq 0) { Write-Host '  (Chua phat hien cong COM nao. Hay cam cap USB vao may)' } else { $p | ForEach-Object { Write-Host ('  -> Cong COM: ' + $_) } }"
echo ---------------------------------------------------------------------
echo.

:CHON_COM
set "USER_COM="
set /p USER_COM="-> Nhap so cong COM (vi du nhap 3 hoac COM3): "
if not defined USER_COM (
    echo Vui long nhap so cong COM!
    goto CHON_COM
)

set "TARGET_COM=%USER_COM: =%"
set "PREFIX=%TARGET_COM:~0,3%"
if /i not "%PREFIX%"=="COM" (
    set "TARGET_COM=COM%TARGET_COM%"
)

echo.
echo [*] Cong COM da chon: %TARGET_COM%
echo.

echo =====================================================================
echo         HUONG DAN DUA BW16 VAO CHE DO NAP (DOWNLOAD MODE)
echo =====================================================================
echo  1. Nhan va GIU nut BURN (hoac chan Log_RX/PA08 xuong GND)
echo  2. Nhan nut RST (Reset) mot lan roi THA RST ra
echo  3. Sau do THA nut BURN ra
echo.
echo  Khi san sang, nhan phim bat ky de bat dau XOA TRANG...
echo =====================================================================
pause >nul

echo.
echo [*] Dang chuan bi thu muc tam thoi de xoa trang...
if exist "_erase_tmp" rd /s /q "_erase_tmp"
md "_erase_tmp"
copy "imgtool_flashloader_amebad.bin" "_erase_tmp\" >nul
copy "upload_image_tool_windows.exe" "_erase_tmp\" >nul
copy "cygwin1.dll" "_erase_tmp\" >nul

echo [*] Dang tien hanh XOA TRANG chip qua cong %TARGET_COM%...
upload_image_tool_windows.exe _erase_tmp %TARGET_COM% AMEBA Disable Enable 1500000

set "ERASE_RES=%ERRORLEVEL%"
rd /s /q "_erase_tmp"

if %ERASE_RES% equ 0 goto XOA_THANH_CONG
goto XOA_THAT_BAI

:XOA_THANH_CONG
echo ---------------------------------------------------------------------
color 0A
echo.
echo =====================================================================
echo             [OK] XOA TRANG CHIP THANH CONG!
echo =====================================================================
echo  Flash cua BW16 da duoc xoa sach 100%% tro ve trang thai moi xuat xuong.
echo  Bay gio hay chay file "2_Xoa_Sach_Flash_Va_Nap_Lai.bat" de nap firmware!
echo =====================================================================
goto KET_THUC

:XOA_THAT_BAI
echo ---------------------------------------------------------------------
color 0C
echo.
echo =====================================================================
echo                 [X] XOA TRANG THAT BAI HOAC CO LOI!
echo =====================================================================
echo  Kiem tra lai: Cong COM, ket noi day va thao tac Giu BURN + Nhan RST.
echo =====================================================================
goto KET_THUC

:KET_THUC
echo.
pause
