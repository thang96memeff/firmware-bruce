#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include "soc/soc_caps.h"
#include <stdint.h>

#ifndef DEVICE_NAME
#define DEVICE_NAME "MyWatch C5"
#endif

#define C5 1
#define ESP32C5 1
#define MYWATCH_C5 1
#define PRO_TOUCH 1

/* --- I2C BUS (TOUCH CST816S & NGOẠI VI) --- */
#define GROVE_SDA 8
#define GROVE_SCL 9
static const uint8_t SDA = GROVE_SDA;
static const uint8_t SCL = GROVE_SCL;

/* --- MÀN HÌNH ST7789 (240x296) --- */
#define HAS_SCREEN 1
#define USER_SETUP_LOADED 1
#define ST7789_DRIVER 1
#define TFT_WIDTH 240
#define TFT_HEIGHT 296

#define TFT_MOSI 7
#define TFT_SCLK 6
#define TFT_CS   23
#define TFT_DC   24
#define TFT_RST  10
#define TFT_BL   25
#define TFT_MISO -1
#define TFT_BACKLIGHT_ON 1

#define CGRAM_OFFSET 1
#define SMOOTH_FONT 1
#define ROTATION 0
#define TFT_MIRROR_X 1
#define MINBRIGHT 1

#define SPI_FREQUENCY 40000000
#define SPI_READ_FREQUENCY 20000000

/* --- CẢM ỨNG CST816S --- */
#define HAS_TOUCH 1
#define TOUCH_SDA 8
#define TOUCH_SCL 9
#define TOUCH_INT 2
#define TOUCH_RST 14
#define CST816_ADDR 0x15

/* --- ĐO PIN (ADC TRỞ CHIA ÁP) --- */
#define BAT_PIN 4

/* --- BUS SPI NGOẠI VI --- */
#define SPI_SCK_PIN -1
#define SPI_MOSI_PIN -1
#define SPI_MISO_PIN -1
#define SPI_SS_PIN -1

static const uint8_t MOSI = 7;
static const uint8_t MISO = -1;
static const uint8_t SCK = 6;
static const uint8_t SS = 23;

#define RF_CE_PIN -1
#define RF_CS_PIN -1

// CC1101 Sub-GHz
#define CC1101_GDO0_PIN -1
#define CC1101_SS_PIN -1
#define CC1101_MOSI_PIN -1
#define CC1101_SCK_PIN -1
#define CC1101_MISO_PIN -1

// NRF24L01 2.4GHz
#define NRF24_CE_PIN -1
#define NRF24_SS_PIN -1
#define NRF24_MOSI_PIN -1
#define NRF24_SCK_PIN -1
#define NRF24_MISO_PIN -1

// W5500 Ethernet
#define W5500_INT_PIN -1
#define W5500_SS_PIN -1
#define W5500_MOSI_PIN -1
#define W5500_SCK_PIN -1
#define W5500_MISO_PIN -1

// SDCard (Đồng hồ không dùng thẻ nhớ, disable để không hijack bus SPI màn hình)
#define SDCARD_CS -1
#define SDCARD_SCK -1
#define SDCARD_MISO -1
#define SDCARD_MOSI -1

/* --- SERIAL --- */
static const uint8_t TX = 11;
static const uint8_t RX = 12;
#define SERIAL_TX 11
#define SERIAL_RX 12
#define BAD_TX 11
#define BAD_RX 12
#define GPS_SERIAL_TX 11
#define GPS_SERIAL_RX 12

#define TXLED -1
#define RXLED -1
#define LED_ON HIGH
#define LED_OFF LOW

#endif /* Pins_Arduino_h */
