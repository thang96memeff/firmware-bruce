#if defined(MYWATCH_C5)

#include "core/powerSave.h"
#include "core/utils.h"
#include "core/pro_touch.h"
#include "core/mykeyboard.h"
#include <Arduino.h>
#include <Wire.h>
#include <globals.h>
#include <interface.h>

#ifndef MINBRIGHT
#define MINBRIGHT 1
#endif

#define CST816_ADDR 0x15

bool readTouchSensor(int &x, int &y) {
    static int last_raw_x = -1;
    static int last_raw_y = -1;

    Wire.beginTransmission(CST816_ADDR);
    Wire.write(0x01); // Bắt đầu đọc từ thanh ghi GESTURE ID của CST813/CST816
    if (Wire.endTransmission(false) != 0) {
        last_raw_x = -1;
        last_raw_y = -1;
        return false;
    }

    Wire.requestFrom((uint8_t)CST816_ADDR, (size_t)6);
    if (Wire.available() >= 6) {
        uint8_t cst_gesture = Wire.read();
        uint8_t fingers = Wire.read();
        uint8_t xh = Wire.read();
        uint8_t xl = Wire.read();
        uint8_t yh = Wire.read();
        uint8_t yl = Wire.read();

        if (fingers > 0) {
            int raw_x = ((xh & 0x0F) << 8) | xl;
            int raw_y = ((yh & 0x0F) << 8) | yl;

            if (raw_x >= 0 && raw_x < 240 && raw_y >= 0 && raw_y < 296) {
                // Bộ lọc làm mịn mượt mà không có deadzone
                if (last_raw_x == -1) {
                    x = raw_x;
                    y = raw_y;
                } else {
                    x = (int)roundf(raw_x * 0.8f + last_raw_x * 0.2f);
                    y = (int)roundf(raw_y * 0.8f + last_raw_y * 0.2f);
                }
                last_raw_x = x;
                last_raw_y = y;
                return true;
            }
        }
    }
    last_raw_x = -1;
    last_raw_y = -1;
    return false;
}

void _setup_gpio() {
    Serial.setTxTimeoutMs(10);
    Serial.println("\n\n========================================");
    Serial.println("       BRUCE FIRMWARE - MYWATCH C5       ");
    Serial.println("========================================");

    // 1. Khóa các chân CS lên HIGH
    pinMode(TFT_CS, OUTPUT);
    digitalWrite(TFT_CS, HIGH);

    // 2. Chu trình reset cứng ST7789 đúng chuẩn MyWatchOS
    pinMode(TFT_RST, OUTPUT);
    digitalWrite(TFT_RST, HIGH);
    delay(10);
    digitalWrite(TFT_RST, LOW);
    delay(50);
    digitalWrite(TFT_RST, HIGH);
    delay(200);

    // 3. I2C cho CST813
    Wire.begin(TOUCH_SDA, TOUCH_SCL);
    Wire.setClock(400000);
    Wire.setTimeout(50);

    // Cấu hình CST813 chuẩn MyWatchOS không tự ngủ
    Wire.beginTransmission(CST816_ADDR); Wire.write(0xFE); Wire.write(0x00); Wire.endTransmission();
    Wire.beginTransmission(CST816_ADDR); Wire.write(0xEE); Wire.write(0x00); Wire.endTransmission();

    // 4. Pin đo áp
    pinMode(BAT_PIN, INPUT);

    // 5. Mặc định màu chuẩn (colorInverted = 0)
    bruceConfig.colorInverted = 0;

    // 6. Bật đèn nền
    pinMode(TFT_BL, OUTPUT);
    analogWrite(TFT_BL, 200);

    Serial.println("[MYWATCH] _setup_gpio done");
}

void _post_setup_gpio() {
    tft.invertDisplay(bruceConfig.colorInverted);
    _setBrightness(bruceConfig.bright);
    Serial.println("[MYWATCH] _post_setup_gpio done");
}

int getBattery() {
    static unsigned long lastCheck = 0;
    static int cachedBat = 100;
    if (millis() - lastCheck > 5000 || lastCheck == 0) {
        lastCheck = millis();
        int raw = analogRead(BAT_PIN);
        // Trở chia đôi áp: 4.2V -> 2.1V vào ADC
        float v_bat = (raw / 4095.0f) * 3.3f * 2.0f;
        int pct = (int)((v_bat - 3.2f) / (4.2f - 3.2f) * 100.0f);
        cachedBat = constrain(pct, 0, 100);
    }
    return cachedBat;
}

bool isCharging() {
    return false;
}

void _setBrightness(uint8_t brightval) {
    if (brightval == 0) {
        analogWrite(TFT_BL, 0);
    } else {
        int bl = MINBRIGHT + round(((255 - MINBRIGHT) * brightval / 100));
        analogWrite(TFT_BL, bl);
    }
}

void InputHandler(void) {
#if defined(PRO_TOUCH)
    if (inProTouch && !inKeyboard) {
        // While ProTouch kinetic engine is actively running, ProTouch directly reads CST813.
        // Prevent taskInputHandler from accessing I2C simultaneously to avoid bus collisions.
        return;
    }
#endif
    extern volatile bool inTextViewer;
    extern volatile bool inNaoyaMenu;
    extern bool inKeyboard;
    if (inTextViewer || inNaoyaMenu || inKeyboard) return;

    static unsigned long lastPressTime = 0;
    static int startTouchX = -1;

    int x, y;
    if (readTouchSensor(x, y)) {
        wakeUpScreen();
        touchPoint.x = x;
        touchPoint.y = y;
        touchPoint.pressed = true;
        AnyKeyPress = true;

        unsigned long now = millis();

        if (startTouchX == -1) startTouchX = x;
        int dx = x - startTouchX;

        // Swipe left/right gesture
        if (abs(dx) > 40 && (now - lastPressTime >= 150)) {
            lastPressTime = now;
            if (dx < 0) {
                PrevPress = true;
            } else {
                NextPress = true;
            }
            AnyKeyPress = true;
            startTouchX = x;
        } else if (now - lastPressTime >= 180) {
            lastPressTime = now;
            touchHeatMap(touchPoint);
        }
    } else {
        touchPoint.pressed = false;
        startTouchX = -1;
    }
}

void powerOff() {
    digitalWrite(TFT_BL, LOW);
    esp_deep_sleep_start();
}

void checkReboot() {}

#endif // MYWATCH_C5
